import Link from 'next/link';

export type ListingCardData = {
  id: string; title: string; rank: string; skins: number; heroes: number; price: number; is_featured: boolean;
  listing_images?: { url: string }[];
  profiles?: { username: string; verified_seller: boolean } | null;
};

export function ListingCard({ listing }: { listing: ListingCardData }) {
  const image = listing.listing_images?.[0]?.url || '/listing-fallback.svg';
  return (
    <Link className="card" href={`/listings/${listing.id}`}>
      <img className="card-img" src={image} alt={`${listing.title} screenshot`} />
      <div className="card-body">
        <div className="meta">
          {listing.is_featured && <span className="badge badge-warn">Featured</span>}
          <span className={listing.profiles?.verified_seller ? 'badge badge-ok' : 'badge'}>{listing.profiles?.verified_seller ? 'Verified Seller' : 'New Seller'}</span>
        </div>
        <h3>{listing.title}</h3>
        <p className="meta">{listing.rank} · {listing.skins} skins · {listing.heroes} heroes</p>
        <p className="price">MMK {Number(listing.price).toLocaleString()}</p>
      </div>
    </Link>
  );
}
