# Mobile Legends Account Marketplace

A production-ready Next.js App Router marketplace for Mobile Legends account listings with buyer/seller/admin roles, manual payment approval, reporting, and image uploads.

## Features

- Home page with featured listings and filters for rank, price, and skin count
- Account detail pages with gallery, seller badge, and Telegram/Facebook/Viber contact buttons
- Register/login with username, phone number, Telegram, Facebook profile, and buyer/seller role selection
- Seller dashboard for submitting listings, uploading screenshots, and uploading listing-fee payment proof
- Manual payment approval with KPay, Wave Money, and AYA Pay
- Admin panel for approving/rejecting listings, verifying sellers, banning users, changing fees, and reviewing reports
- Anti-scam flow: report seller, suspicious seller auto-flagging, ban system, review queue
- Supabase PostgreSQL schema, storage buckets, RLS, and role-based access using a separate `user_roles` table
- Vercel Free compatible: no custom server, only App Router and serverless API routes

## Quick Start

```bash
npm install
cp .env.example .env.local
npm run dev
```

Open `http://localhost:3000`.

## Database Setup

1. Create a Supabase project.
2. Open SQL Editor.
3. Run `supabase/schema.sql`.
4. In Storage, confirm the buckets `listing-screenshots` and `payment-proofs` exist. The schema creates them automatically.
5. Create your first admin by registering a user, then run:

```sql
insert into public.user_roles (user_id, role)
values ('YOUR_AUTH_USER_ID', 'admin')
on conflict do nothing;
```

Roles are intentionally stored only in `public.user_roles`, never in profiles/users, to prevent privilege escalation.

## Environment Variables

For local development, create `.env.local`:

```env
NEXT_PUBLIC_SUPABASE_URL=...
NEXT_PUBLIC_SUPABASE_ANON_KEY=...
SUPABASE_SERVICE_ROLE_KEY=...
NEXT_PUBLIC_SITE_URL=http://localhost:3000
```

`SUPABASE_SERVICE_ROLE_KEY` must only be used on the server. Never expose it in client components.

## GitHub Setup

```bash
git init
git add .
git commit -m "Initial Mobile Legends marketplace"
git branch -M main
git remote add origin https://github.com/YOUR_USERNAME/YOUR_REPO.git
git push -u origin main
```

## Vercel Deployment

1. Push the project to GitHub.
2. Go to Vercel → Add New Project → Import your repository.
3. Add the same environment variables from `.env.example`.
4. Deploy. The app works on Vercel Free because it uses serverless API routes and Supabase for persistence/storage.
5. In Supabase Auth settings, add your Vercel URL to allowed redirect URLs.

## Project Structure

```txt
app/                    Next.js App Router pages and API routes
components/             Reusable UI components
lib/                    Supabase clients, validation, auth helpers
supabase/schema.sql     Full PostgreSQL schema, RLS, storage, policies
```

## Security Notes

- Admin checks are server-side through `public.has_role()` and `user_roles`.
- RLS is enabled on all application tables.
- Server API routes validate input with Zod.
- Banned users are blocked from creating listings, payments, and reports.
- Public contact information is shown only for approved listings.
