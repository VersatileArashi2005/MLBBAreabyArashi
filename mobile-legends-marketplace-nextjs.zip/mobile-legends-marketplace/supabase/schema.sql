-- Mobile Legends Account Marketplace full schema
-- Run this in Supabase SQL Editor.

create extension if not exists pgcrypto;

create type public.app_role as enum ('admin', 'seller', 'buyer');
create type public.listing_status as enum ('pending', 'approved', 'rejected');
create type public.payment_status as enum ('pending', 'approved', 'rejected');
create type public.report_status as enum ('open', 'resolved', 'dismissed');

create table public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  username text not null unique check (char_length(username) between 3 and 40),
  phone text not null check (char_length(phone) between 6 and 30),
  telegram text not null check (char_length(telegram) between 3 and 60),
  facebook text not null check (facebook ~* '^https?://'),
  verified_seller boolean not null default false,
  suspicious boolean not null default false,
  banned boolean not null default false,
  created_at timestamptz not null default now()
);

create table public.user_roles (
  id uuid primary key default gen_random_uuid(),
  user_id uuid references auth.users(id) on delete cascade not null,
  role public.app_role not null,
  unique (user_id, role)
);

create table public.listings (
  id uuid primary key default gen_random_uuid(),
  seller_id uuid not null references public.profiles(id) on delete cascade,
  title text not null check (char_length(title) between 8 and 120),
  description text not null check (char_length(description) between 30 and 4000),
  rank text not null,
  skins integer not null check (skins >= 0),
  heroes integer not null check (heroes >= 0),
  server text not null,
  price numeric(12,2) not null check (price > 0),
  status public.listing_status not null default 'pending',
  is_featured_requested boolean not null default false,
  is_featured boolean not null default false,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table public.listing_images (
  id uuid primary key default gen_random_uuid(),
  listing_id uuid not null references public.listings(id) on delete cascade,
  url text not null,
  storage_path text not null,
  created_at timestamptz not null default now()
);

create table public.payments (
  id uuid primary key default gen_random_uuid(),
  listing_id uuid not null references public.listings(id) on delete cascade,
  user_id uuid not null references public.profiles(id) on delete cascade,
  method text not null check (method in ('KPay','Wave Money','AYA Pay')),
  amount numeric(12,2) not null check (amount > 0),
  transaction_reference text not null,
  screenshot_url text not null,
  screenshot_path text not null,
  status public.payment_status not null default 'pending',
  created_at timestamptz not null default now()
);

create table public.reports (
  id uuid primary key default gen_random_uuid(),
  reporter_id uuid not null references public.profiles(id) on delete cascade,
  seller_id uuid not null references public.profiles(id) on delete cascade,
  listing_id uuid references public.listings(id) on delete set null,
  reason text not null check (char_length(reason) between 10 and 1000),
  status public.report_status not null default 'open',
  created_at timestamptz not null default now()
);

create table public.settings (
  key text primary key,
  value numeric not null,
  updated_at timestamptz not null default now()
);
insert into public.settings (key, value) values ('listing_fee', 5000) on conflict do nothing;

create or replace function public.has_role(_user_id uuid, _role public.app_role)
returns boolean
language sql
stable
security definer
set search_path = public
as $$
  select exists (select 1 from public.user_roles where user_id = _user_id and role = _role)
$$;

create or replace function public.is_banned(_user_id uuid)
returns boolean
language sql
stable
security definer
set search_path = public
as $$
  select coalesce((select banned from public.profiles where id = _user_id), true)
$$;

create or replace function public.touch_updated_at()
returns trigger language plpgsql as $$
begin new.updated_at = now(); return new; end; $$;
create trigger listings_touch_updated_at before update on public.listings for each row execute function public.touch_updated_at();

alter table public.profiles enable row level security;
alter table public.user_roles enable row level security;
alter table public.listings enable row level security;
alter table public.listing_images enable row level security;
alter table public.payments enable row level security;
alter table public.reports enable row level security;
alter table public.settings enable row level security;

create policy "Public profiles visible for contact" on public.profiles for select using (true);
create policy "Users update own profile if not banned" on public.profiles for update to authenticated using (auth.uid() = id and not public.is_banned(auth.uid())) with check (auth.uid() = id);
create policy "Admins manage profiles" on public.profiles for all to authenticated using (public.has_role(auth.uid(), 'admin')) with check (public.has_role(auth.uid(), 'admin'));

create policy "Users read own roles" on public.user_roles for select to authenticated using (user_id = auth.uid());
create policy "Admins manage roles" on public.user_roles for all to authenticated using (public.has_role(auth.uid(), 'admin')) with check (public.has_role(auth.uid(), 'admin'));

create policy "Approved listings are public" on public.listings for select using (status = 'approved' or seller_id = auth.uid() or public.has_role(auth.uid(), 'admin'));
create policy "Sellers create listings" on public.listings for insert to authenticated with check (seller_id = auth.uid() and public.has_role(auth.uid(), 'seller') and not public.is_banned(auth.uid()));
create policy "Sellers update pending own listings" on public.listings for update to authenticated using (seller_id = auth.uid() and status = 'pending') with check (seller_id = auth.uid());
create policy "Admins manage listings" on public.listings for all to authenticated using (public.has_role(auth.uid(), 'admin')) with check (public.has_role(auth.uid(), 'admin'));

create policy "Images follow listings" on public.listing_images for select using (exists (select 1 from public.listings l where l.id = listing_id and (l.status='approved' or l.seller_id=auth.uid() or public.has_role(auth.uid(),'admin'))));
create policy "Admins manage listing images" on public.listing_images for all to authenticated using (public.has_role(auth.uid(), 'admin')) with check (public.has_role(auth.uid(), 'admin'));

create policy "Users see own payments" on public.payments for select to authenticated using (user_id = auth.uid() or public.has_role(auth.uid(), 'admin'));
create policy "Users create own payments" on public.payments for insert to authenticated with check (user_id = auth.uid() and not public.is_banned(auth.uid()));
create policy "Admins manage payments" on public.payments for all to authenticated using (public.has_role(auth.uid(), 'admin')) with check (public.has_role(auth.uid(), 'admin'));

create policy "Report participants and admins read" on public.reports for select to authenticated using (reporter_id = auth.uid() or seller_id = auth.uid() or public.has_role(auth.uid(), 'admin'));
create policy "Authenticated users create reports" on public.reports for insert to authenticated with check (reporter_id = auth.uid() and not public.is_banned(auth.uid()));
create policy "Admins manage reports" on public.reports for all to authenticated using (public.has_role(auth.uid(), 'admin')) with check (public.has_role(auth.uid(), 'admin'));

create policy "Settings public read" on public.settings for select using (true);
create policy "Admins manage settings" on public.settings for all to authenticated using (public.has_role(auth.uid(), 'admin')) with check (public.has_role(auth.uid(), 'admin'));

insert into storage.buckets (id, name, public) values ('listing-screenshots', 'listing-screenshots', true) on conflict do nothing;
insert into storage.buckets (id, name, public) values ('payment-proofs', 'payment-proofs', true) on conflict do nothing;

create policy "Public listing screenshots" on storage.objects for select using (bucket_id = 'listing-screenshots');
create policy "Public payment proofs for admin workflow" on storage.objects for select using (bucket_id = 'payment-proofs');
create policy "Authenticated upload listing screenshots" on storage.objects for insert to authenticated with check (bucket_id = 'listing-screenshots' and not public.is_banned(auth.uid()));
create policy "Authenticated upload payment proofs" on storage.objects for insert to authenticated with check (bucket_id = 'payment-proofs' and not public.is_banned(auth.uid()));
