import './globals.css';
import Link from 'next/link';
import type { Metadata } from 'next';
import { getCurrentUser } from '@/lib/auth';

export const metadata: Metadata = {
  title: 'ML Account Market',
  description: 'Secure Mobile Legends account marketplace with verified sellers, manual payment approval, and anti-scam reporting.'
};

export default async function RootLayout({ children }: { children: React.ReactNode }) {
  const user = await getCurrentUser();
  return (
    <html lang="en">
      <body>
        <header className="nav">
          <div className="container nav-inner">
            <Link className="logo" href="/"><span className="logo-mark" /> ML Account Market</Link>
            <nav className="nav-links">
              <Link href="/">Listings</Link>
              <Link href="/seller-guide">Seller Guide</Link>
              <Link href="/dashboard">Seller Dashboard</Link>
              <Link href="/admin">Admin</Link>
              {user ? <form action="/auth/logout" method="post"><button className="btn btn-secondary">Logout</button></form> : <Link className="btn btn-primary" href="/login">Login</Link>}
            </nav>
          </div>
        </header>
        {children}
        <footer className="footer"><div className="container">Manual-approval Mobile Legends account marketplace. Trade safely and report suspicious sellers.</div></footer>
      </body>
    </html>
  );
}
