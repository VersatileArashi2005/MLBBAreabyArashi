import { requireUser } from '@/lib/auth';
import { createSupabaseServerClient } from '@/lib/supabase/server';

export default async function Dashboard() {
  const user = await requireUser();
  const supabase = await createSupabaseServerClient();
  const { data: listings } = await supabase.from('listings').select('*').eq('seller_id', user.id).order('created_at', { ascending: false });
  const { data: fee } = await supabase.from('settings').select('value').eq('key', 'listing_fee').single();
  return (
    <main className="container section">
      <h1>Seller Dashboard</h1>
      <p className="notice">Current listing fee: MMK {Number(fee?.value || 0).toLocaleString()}. Upload payment proof after submitting your account.</p>
      <section className="two-col">
        <form className="panel form" action="/api/listings" method="post" encType="multipart/form-data">
          <h2>Submit Account Listing</h2>
          <input className="input" name="title" placeholder="Title" required />
          <textarea className="input" name="description" placeholder="Full account description" rows={6} required />
          <input className="input" name="rank" placeholder="Rank" required />
          <input className="input" name="skins" type="number" placeholder="Skin count" required />
          <input className="input" name="heroes" type="number" placeholder="Hero count" required />
          <input className="input" name="server" placeholder="Server" required />
          <input className="input" name="price" type="number" placeholder="Price MMK" required />
          <label className="badge"><input name="is_featured_requested" type="checkbox" value="true" /> Request featured listing</label>
          <input className="input" name="screenshots" type="file" accept="image/*" multiple required />
          <button className="btn btn-primary">Submit for review</button>
        </form>
        <div className="panel">
          <h2>Your Listings</h2>
          <table className="table"><tbody>{listings?.map((l) => <tr key={l.id}><td>{l.title}</td><td><span className="badge">{l.status}</span></td><td>MMK {Number(l.price).toLocaleString()}</td></tr>)}</tbody></table>
        </div>
      </section>
      <section className="panel" style={{marginTop:20}}>
        <h2>Upload Listing Fee Payment Screenshot</h2>
        <form className="form" action="/api/payments" method="post" encType="multipart/form-data">
          <select className="input" name="listing_id" required>{listings?.map((l) => <option key={l.id} value={l.id}>{l.title}</option>)}</select>
          <select className="input" name="method"><option>KPay</option><option>Wave Money</option><option>AYA Pay</option></select>
          <input className="input" name="amount" type="number" placeholder="Amount paid" required />
          <input className="input" name="transaction_reference" placeholder="Transaction reference" required />
          <input className="input" name="screenshot" type="file" accept="image/*" required />
          <button className="btn btn-primary">Upload proof</button>
        </form>
      </section>
    </main>
  );
}
