import { createSupabaseServerClient } from '@/lib/supabase/server';
import { ListingCard, ListingCardData } from '@/components/ListingCard';

export default async function Home({ searchParams }: { searchParams: Promise<Record<string, string | undefined>> }) {
  const params = await searchParams;
  const supabase = await createSupabaseServerClient();
  let query = supabase
    .from('listings')
    .select('id,title,rank,skins,heroes,price,is_featured,listing_images(url),profiles(username,verified_seller)')
    .eq('status', 'approved')
    .order('is_featured', { ascending: false })
    .order('created_at', { ascending: false });

  if (params.rank) query = query.ilike('rank', `%${params.rank}%`);
  if (params.min_price) query = query.gte('price', Number(params.min_price));
  if (params.max_price) query = query.lte('price', Number(params.max_price));
  if (params.min_skins) query = query.gte('skins', Number(params.min_skins));

  const { data: listings } = await query;
  const featured = (listings || []).filter((l: any) => l.is_featured).slice(0, 3) as ListingCardData[];

  return (
    <main>
      <section className="container hero">
        <div>
          <span className="badge badge-warn">Manual approval · Anti-scam review</span>
          <h1>Buy and sell Mobile Legends accounts safely.</h1>
          <p className="lead">Browse ranked accounts, inspect screenshots, contact verified sellers, and let admins review payments and suspicious activity before listings go live.</p>
          <div className="stat-grid">
            <div className="stat"><strong>{listings?.length || 0}</strong><span className="meta">Approved listings</span></div>
            <div className="stat"><strong>{featured.length}</strong><span className="meta">Featured today</span></div>
            <div className="stat"><strong>24/7</strong><span className="meta">Report queue</span></div>
          </div>
        </div>
        <div className="hero-art"><h2>Mythic deals, verified proof.</h2><p className="lead">Upload account screenshots, payment proof, and keep every listing under admin review.</p></div>
      </section>

      <section className="container section">
        <h2>Featured Listings</h2>
        <div className="grid">{featured.map((listing) => <ListingCard key={listing.id} listing={listing} />)}</div>
      </section>

      <section className="container section">
        <h2>All Accounts</h2>
        <form className="filters">
          <input className="input" name="rank" placeholder="Rank e.g. Mythic" defaultValue={params.rank} />
          <input className="input" name="min_price" type="number" placeholder="Min price" defaultValue={params.min_price} />
          <input className="input" name="max_price" type="number" placeholder="Max price" defaultValue={params.max_price} />
          <input className="input" name="min_skins" type="number" placeholder="Minimum skins" defaultValue={params.min_skins} />
          <button className="btn btn-primary">Apply filters</button>
        </form>
        <div className="grid">{(listings || []).map((listing: any) => <ListingCard key={listing.id} listing={listing} />)}</div>
      </section>
    </main>
  );
}
