import { requireRole } from '@/lib/auth';
import { createSupabaseServerClient } from '@/lib/supabase/server';

export default async function AdminPage() {
  await requireRole('admin');
  const supabase = await createSupabaseServerClient();
  const { data: listings } = await supabase.from('listings').select('*,profiles(username)').order('created_at', { ascending: false }).limit(50);
  const { data: payments } = await supabase.from('payments').select('*,listings(title)').order('created_at', { ascending: false }).limit(50);
  const { data: reports } = await supabase.from('reports').select('*,seller:profiles!reports_seller_id_fkey(username,suspicious,banned)').order('created_at', { ascending: false }).limit(50);
  const { data: users } = await supabase.from('profiles').select('*').order('created_at', { ascending: false }).limit(50);
  return (
    <main className="container section">
      <h1>Admin Panel</h1>
      <section className="panel"><h2>Manage Listing Fee</h2><form className="form" action="/api/admin/settings" method="post"><input type="hidden" name="key" value="listing_fee" /><input className="input" name="value" type="number" placeholder="Listing fee MMK" /><button className="btn btn-primary">Save fee</button></form></section>
      <section className="panel" style={{marginTop:20}}><h2>Listings</h2><table className="table"><tbody>{listings?.map((l:any)=><tr key={l.id}><td>{l.title}<br/><span className="meta">{l.profiles?.username} · {l.status}</span></td><td><AdminAction endpoint="/api/admin/listings" id={l.id} approve="approved" reject="rejected" /></td></tr>)}</tbody></table></section>
      <section className="panel" style={{marginTop:20}}><h2>Payments</h2><table className="table"><tbody>{payments?.map((p:any)=><tr key={p.id}><td>{p.listings?.title}<br/><a className="badge" href={p.screenshot_url} target="_blank">View screenshot</a></td><td>{p.method} · MMK {Number(p.amount).toLocaleString()} · {p.status}</td><td><AdminAction endpoint="/api/admin/payments" id={p.id} approve="approved" reject="rejected" /></td></tr>)}</tbody></table></section>
      <section className="panel" style={{marginTop:20}}><h2>Reports</h2><table className="table"><tbody>{reports?.map((r:any)=><tr key={r.id}><td>{r.reason}<br/><span className="meta">Seller: {r.seller?.username} · {r.status}</span></td><td><AdminAction endpoint="/api/admin/reports" id={r.id} approve="resolved" reject="dismissed" /></td></tr>)}</tbody></table></section>
      <section className="panel" style={{marginTop:20}}><h2>Users</h2><table className="table"><tbody>{users?.map((u:any)=><tr key={u.id}><td>{u.username}<br/><span className="meta">{u.suspicious ? 'Suspicious · ' : ''}{u.banned ? 'Banned' : 'Active'}</span></td><td><form action="/api/admin/users" method="post"><input type="hidden" name="id" value={u.id}/><button name="action" value="verify" className="btn btn-secondary">Verify</button> <button name="action" value="ban" className="btn btn-danger">Ban</button></form></td></tr>)}</tbody></table></section>
    </main>
  );
}

function AdminAction({ endpoint, id, approve, reject }: { endpoint:string; id:string; approve:string; reject:string }) {
  return <form action={endpoint} method="post"><input type="hidden" name="id" value={id}/><button className="btn btn-primary" name="status" value={approve}>Approve</button> <button className="btn btn-danger" name="status" value={reject}>Reject</button></form>;
}
