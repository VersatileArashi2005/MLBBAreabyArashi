import { NextRequest, NextResponse } from 'next/server';
import { createSupabaseAdminClient, createSupabaseServerClient } from '@/lib/supabase/server';
import { registerSchema } from '@/lib/validators';

export async function POST(req: NextRequest) {
  const form = Object.fromEntries((await req.formData()).entries());
  const parsed = registerSchema.safeParse(form);
  if (!parsed.success) return NextResponse.json({ error: parsed.error.flatten() }, { status: 400 });
  const supabase = await createSupabaseServerClient();
  const admin = createSupabaseAdminClient();
  const { email, password, role, username, phone, telegram, facebook } = parsed.data;
  const { data, error } = await supabase.auth.signUp({ email, password });
  if (error || !data.user) return NextResponse.json({ error: error?.message || 'Registration failed' }, { status: 400 });
  await admin.from('profiles').insert({ id: data.user.id, username, phone, telegram, facebook });
  await admin.from('user_roles').insert([{ user_id: data.user.id, role: 'buyer' }, { user_id: data.user.id, role }]).select();
  return NextResponse.redirect(new URL('/dashboard', req.url), 303);
}
