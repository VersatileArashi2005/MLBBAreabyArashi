export default function LoginPage() {
  return (
    <main className="container section two-col">
      <section className="panel">
        <h1>Login</h1>
        <form className="form" action="/auth/login" method="post">
          <input className="input" name="email" type="email" placeholder="Email" required />
          <input className="input" name="password" type="password" placeholder="Password" required />
          <button className="btn btn-primary">Login</button>
        </form>
      </section>
      <section className="panel">
        <h1>Register</h1>
        <form className="form" action="/auth/register" method="post">
          <input className="input" name="email" type="email" placeholder="Email" required />
          <input className="input" name="password" type="password" placeholder="Password, min 8 characters" required />
          <input className="input" name="username" placeholder="Username" required />
          <input className="input" name="phone" placeholder="Phone number / Viber" required />
          <input className="input" name="telegram" placeholder="Telegram username" required />
          <input className="input" name="facebook" type="url" placeholder="Facebook profile link" required />
          <select className="input" name="role" required><option value="buyer">Buyer</option><option value="seller">Seller</option></select>
          <button className="btn btn-primary">Create account</button>
        </form>
      </section>
    </main>
  );
}
