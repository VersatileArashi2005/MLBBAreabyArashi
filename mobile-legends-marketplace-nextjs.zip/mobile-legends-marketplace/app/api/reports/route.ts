import { NextRequest, NextResponse } from 'next/server';
import { createSupabaseAdminClient, createSupabaseServerClient } from '@/lib/supabase/server';
import { reportSchema } from '@/lib/validators';

export async function POST(req: NextRequest) {
  const supabase = await createSupabaseServerClient();
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) return NextResponse.json({ error: 'Login required' }, { status: 401 });
  const form = Object.fromEntries((await req.formData()).entries());
  if (!form.listing_id) delete form.listing_id;
  const parsed = reportSchema.safeParse(form);
  if (!parsed.success) return NextResponse.json({ error: parsed.error.flatten() }, { status: 400 });
  const admin = createSupabaseAdminClient();
  await admin.from('reports').insert({ ...parsed.data, reporter_id: user.id, status: 'open' });
  const { count } = await admin.from('reports').select('*', { count: 'exact', head: true }).eq('seller_id', parsed.data.seller_id).eq('status', 'open');
  if ((count || 0) >= 3) await admin.from('profiles').update({ suspicious: true }).eq('id', parsed.data.seller_id);
  return NextResponse.redirect(new URL('/', req.url), 303);
}
