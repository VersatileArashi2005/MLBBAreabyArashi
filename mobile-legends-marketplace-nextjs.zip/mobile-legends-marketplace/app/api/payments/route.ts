import { NextRequest, NextResponse } from 'next/server';
import { createSupabaseAdminClient, createSupabaseServerClient } from '@/lib/supabase/server';
import { paymentSchema } from '@/lib/validators';

export async function POST(req: NextRequest) {
  const supabase = await createSupabaseServerClient();
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) return NextResponse.json({ error: 'Login required' }, { status: 401 });
  const admin = createSupabaseAdminClient();
  const form = await req.formData();
  const parsed = paymentSchema.safeParse(Object.fromEntries(form.entries()));
  if (!parsed.success) return NextResponse.json({ error: parsed.error.flatten() }, { status: 400 });
  const file = form.get('screenshot');
  if (!(file instanceof File)) return NextResponse.json({ error: 'Payment screenshot is required' }, { status: 400 });
  const { data: listing } = await admin.from('listings').select('seller_id').eq('id', parsed.data.listing_id).single();
  if (!listing || listing.seller_id !== user.id) return NextResponse.json({ error: 'Not your listing' }, { status: 403 });
  const ext = file.name.split('.').pop() || 'jpg';
  const path = `${user.id}/${parsed.data.listing_id}/${crypto.randomUUID()}.${ext}`;
  const upload = await admin.storage.from('payment-proofs').upload(path, file, { contentType: file.type });
  if (upload.error) return NextResponse.json({ error: upload.error.message }, { status: 400 });
  const { data: pub } = admin.storage.from('payment-proofs').getPublicUrl(path);
  await admin.from('payments').insert({ ...parsed.data, user_id: user.id, screenshot_url: pub.publicUrl, screenshot_path: path, status: 'pending' });
  return NextResponse.redirect(new URL('/dashboard', req.url), 303);
}
