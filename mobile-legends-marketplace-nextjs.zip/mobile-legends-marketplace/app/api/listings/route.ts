import { NextRequest, NextResponse } from 'next/server';
import { createSupabaseAdminClient, createSupabaseServerClient } from '@/lib/supabase/server';
import { listingSchema } from '@/lib/validators';

export async function POST(req: NextRequest) {
  const supabase = await createSupabaseServerClient();
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) return NextResponse.json({ error: 'Login required' }, { status: 401 });
  const isSeller = await supabase.rpc('has_role', { _user_id: user.id, _role: 'seller' });
  if (!isSeller.data) return NextResponse.json({ error: 'Seller role required' }, { status: 403 });
  const admin = createSupabaseAdminClient();
  const { data: profile } = await admin.from('profiles').select('banned').eq('id', user.id).single();
  if (profile?.banned) return NextResponse.json({ error: 'Banned users cannot submit listings' }, { status: 403 });

  const form = await req.formData();
  const parsed = listingSchema.safeParse(Object.fromEntries(form.entries()));
  if (!parsed.success) return NextResponse.json({ error: parsed.error.flatten() }, { status: 400 });
  const { data: listing, error } = await admin.from('listings').insert({ ...parsed.data, seller_id: user.id, status: 'pending' }).select().single();
  if (error) return NextResponse.json({ error: error.message }, { status: 400 });

  const files = form.getAll('screenshots').filter((f): f is File => f instanceof File);
  for (const file of files.slice(0, 8)) {
    const ext = file.name.split('.').pop() || 'jpg';
    const path = `${user.id}/${listing.id}/${crypto.randomUUID()}.${ext}`;
    const upload = await admin.storage.from('listing-screenshots').upload(path, file, { contentType: file.type, upsert: false });
    if (!upload.error) {
      const { data } = admin.storage.from('listing-screenshots').getPublicUrl(path);
      await admin.from('listing_images').insert({ listing_id: listing.id, url: data.publicUrl, storage_path: path });
    }
  }
  return NextResponse.redirect(new URL('/dashboard', req.url), 303);
}
