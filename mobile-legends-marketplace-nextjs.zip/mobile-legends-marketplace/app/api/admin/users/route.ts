import { NextRequest, NextResponse } from 'next/server';
import { createSupabaseAdminClient, createSupabaseServerClient } from '@/lib/supabase/server';

export async function POST(req: NextRequest) {
  const supabase = await createSupabaseServerClient();
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) return NextResponse.json({ error: 'Login required' }, { status: 401 });
  const { data: isAdmin } = await supabase.rpc('has_role', { _user_id: user.id, _role: 'admin' });
  if (!isAdmin) return NextResponse.json({ error: 'Admin required' }, { status: 403 });
  const form = await req.formData();
  const id = String(form.get('id'));
  const action = String(form.get('action'));
  const admin = createSupabaseAdminClient();
  if (action === 'verify') await admin.from('profiles').update({ verified_seller: true }).eq('id', id);
  if (action === 'ban') await admin.from('profiles').update({ banned: true }).eq('id', id);
  return NextResponse.redirect(new URL('/admin', req.url), 303);
}
