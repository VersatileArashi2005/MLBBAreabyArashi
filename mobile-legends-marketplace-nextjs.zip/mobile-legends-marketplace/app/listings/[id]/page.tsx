import { createSupabaseServerClient } from '@/lib/supabase/server';
import { notFound } from 'next/navigation';
import Link from 'next/link';

export default async function ListingDetail({ params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  const supabase = await createSupabaseServerClient();
  const { data: listing } = await supabase
    .from('listings')
    .select('*, listing_images(url), profiles(id,username,telegram,facebook,phone,verified_seller,created_at)')
    .eq('id', id)
    .eq('status', 'approved')
    .single();
  if (!listing) notFound();
  const seller = Array.isArray(listing.profiles) ? listing.profiles[0] : listing.profiles;
  return (
    <main className="container section">
      <div className="two-col">
        <section className="gallery">{listing.listing_images?.map((img: any) => <img key={img.url} src={img.url} alt={`${listing.title} screenshot`} />)}</section>
        <aside className="panel">
          <span className={seller?.verified_seller ? 'badge badge-ok' : 'badge'}>{seller?.verified_seller ? 'Verified Seller' : 'New Seller'}</span>
          <h1>{listing.title}</h1>
          <p className="price">MMK {Number(listing.price).toLocaleString()}</p>
          <p className="lead">{listing.description}</p>
          <table className="table"><tbody>
            <tr><th>Rank</th><td>{listing.rank}</td></tr>
            <tr><th>Skins</th><td>{listing.skins}</td></tr>
            <tr><th>Heroes</th><td>{listing.heroes}</td></tr>
            <tr><th>Server</th><td>{listing.server}</td></tr>
            <tr><th>Seller</th><td>{seller?.username}</td></tr>
          </tbody></table>
          <div style={{display:'flex',gap:10,flexWrap:'wrap',marginTop:16}}>
            <a className="btn btn-primary" href={`https://t.me/${seller?.telegram?.replace('@','')}`} target="_blank">Telegram</a>
            <a className="btn btn-secondary" href={seller?.facebook || '#'} target="_blank">Facebook</a>
            <a className="btn btn-secondary" href={`viber://chat?number=${seller?.phone}`}>Viber</a>
            <Link className="btn btn-danger" href={`/report?listing=${listing.id}&seller=${seller?.id}`}>Report Seller</Link>
          </div>
        </aside>
      </div>
    </main>
  );
}
