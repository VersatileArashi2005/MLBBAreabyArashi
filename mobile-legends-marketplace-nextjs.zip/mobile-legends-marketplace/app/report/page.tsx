import { requireUser } from '@/lib/auth';

export default async function ReportPage({ searchParams }: { searchParams: Promise<Record<string, string | undefined>> }) {
  await requireUser();
  const params = await searchParams;
  return (
    <main className="container section">
      <section className="panel">
        <h1>Report Seller</h1>
        <form className="form" action="/api/reports" method="post">
          <input type="hidden" name="seller_id" value={params.seller || ''} />
          <input type="hidden" name="listing_id" value={params.listing || ''} />
          <textarea className="input" name="reason" rows={8} placeholder="Describe the suspicious behavior, payment issue, or scam evidence." required />
          <button className="btn btn-danger">Submit report</button>
        </form>
      </section>
    </main>
  );
}
