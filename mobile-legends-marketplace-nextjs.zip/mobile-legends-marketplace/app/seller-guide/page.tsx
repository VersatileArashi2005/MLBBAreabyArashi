export default function SellerGuide() {
  return (
    <main className="container section">
      <h1>Seller Guide</h1>
      <div className="grid">
        <section className="panel"><h2>Posting Rules</h2><p className="lead">Use accurate rank, hero, skin, server, and price information. Do not post stolen, recovered, or misleading accounts. Listings remain pending until admin and payment review are complete.</p></section>
        <section className="panel"><h2>Screenshot Guidelines</h2><p className="lead">Upload clear screenshots showing profile, rank, skins, heroes, server, and important rare items. Hide sensitive login details and recovery information.</p></section>
        <section className="panel"><h2>Scam & Ban Policy</h2><p className="lead">Sellers with repeated reports are auto-flagged for admin review. Confirmed scams, fake screenshots, payment fraud, or harassment can result in permanent bans.</p></section>
      </div>
    </main>
  );
}
