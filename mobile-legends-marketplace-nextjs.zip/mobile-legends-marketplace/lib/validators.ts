import { z } from 'zod';

export const registerSchema = z.object({
  email: z.string().email().max(255),
  password: z.string().min(8).max(100),
  username: z.string().trim().min(3).max(40),
  phone: z.string().trim().min(6).max(30),
  telegram: z.string().trim().min(3).max(60),
  facebook: z.string().url().max(255),
  role: z.enum(['buyer', 'seller'])
});

export const listingSchema = z.object({
  title: z.string().trim().min(8).max(120),
  description: z.string().trim().min(30).max(4000),
  rank: z.string().trim().min(2).max(50),
  skins: z.coerce.number().int().min(0).max(2000),
  heroes: z.coerce.number().int().min(0).max(500),
  server: z.string().trim().min(2).max(60),
  price: z.coerce.number().min(1).max(100000000),
  is_featured_requested: z.coerce.boolean().optional().default(false)
});

export const paymentSchema = z.object({
  listing_id: z.string().uuid(),
  method: z.enum(['KPay', 'Wave Money', 'AYA Pay']),
  amount: z.coerce.number().min(1).max(100000000),
  transaction_reference: z.string().trim().min(3).max(120)
});

export const reportSchema = z.object({
  seller_id: z.string().uuid(),
  listing_id: z.string().uuid().optional(),
  reason: z.string().trim().min(10).max(1000)
});
